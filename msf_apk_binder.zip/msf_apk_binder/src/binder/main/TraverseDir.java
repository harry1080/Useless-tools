package binder.main;

import java.io.File;
import java.util.ArrayList;

public class TraverseDir {
	ArrayList<String> FilePathList = new ArrayList<String>();
	void TraverseFolder2(String path) {
		File file = new File(path);
		if(!file.exists()) {System.out.println("�ļ�������");return;}
		File[] files = file.listFiles();
		if(files == null || files.length ==0) {
			System.out.print("Dir is empty");
			return;
		}else {
			for(File file2 :files) {
				if(file2.isDirectory()) {
					TraverseFolder2(file2.getAbsolutePath());
				}else {
					String cpath = file2.getAbsolutePath();
					FilePathList.add(cpath);
				}
			}
		}
	
	}
	ArrayList<String> TraverseFolder(String FolderPath) {
		TraverseFolder2(FolderPath);
		return FilePathList;
	}
}
